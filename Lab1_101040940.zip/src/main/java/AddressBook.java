import java.util.ArrayList;
import java.util.List;

public class AddressBook {

    private List<BuddyInfo> buddies;

    public AddressBook() {
        buddies = new ArrayList<BuddyInfo>();

    }

    public void setBuddies(ArrayList<BuddyInfo> buddies) {
        this.buddies = buddies;
    }


    public BuddyInfo getBuddy(int x) {
        return buddies.get(x);
    }

    public void addBuddy(BuddyInfo buddy) {
        if(buddy == null) {
            System.out.println("The BuddyInfo you are trying to add cannot be null");
        }
        else {
            buddies.add(buddy);
        }
    }

    public void removeBuddy(int buddyIndex) {
        if (buddyIndex < buddies.size() && buddyIndex >= 0) {
            buddies.remove(buddyIndex);
        }
    }

    public void clear() {
        buddies = new ArrayList<BuddyInfo>();
    }

    public String toString() {
        String s = "";

        for (BuddyInfo b:buddies) {
            s += b.getName();
        }
        return s;
    }


    public static void main(String[] args) {
        AddressBook addressBook = new AddressBook();

        BuddyInfo abdi = new BuddyInfo("Abdillahi", "123 Main Street", "613-555-6666");
        BuddyInfo Joe = new BuddyInfo("Joe", "12 Side Road", "819-123-6789");

        addressBook.addBuddy(abdi);
        addressBook.addBuddy(Joe);

        System.out.println(addressBook);
    }

}
